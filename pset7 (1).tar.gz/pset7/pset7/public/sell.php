<?php
    // configuration
    require("../includes/config.php"); 
    
    // If user reached via GET
    if ($_SERVER["REQUEST_METHOD"] == "GET")
    {
        $rows = CS50::query("SELECT symbol FROM portfolio WHERE user_id = ?", $_SESSION["id"]);
        
        // create new array to store all info for portfolio table
    	$symbols = [];
        foreach ($rows as $row)
        {
            $stock = lookup($row["symbol"]);
            
            if ($stock !== false)
            {
                $symbols[] = [
                    "name" => $stock["name"],
                    "symbol" => $row["symbol"],
                ];
            }
        }
        
        render("sell_form.php", ["tittle" => "Sell", "symbols" => $symbols]);
        
    }
    
    // If user reached via POST
    else if ($_SERVER["REQUEST_METHOD"] == "POST")
    {
        $shares = CS50::query("SELECT shares FROM portfolio WHERE user_id = ? AND symbol = ?", $_SESSION["id"], $_POST["symbol"]);
        $stock = lookup($_POST["symbol"]);
        $profit = $chare[0]["shares"] * $stock["price"];
        
        CS50::query("UPDATE users SET cash = cash + ? WHERE id = ?", $value, $_SESSION["id"]);
        $rows = CS50::query("DELETE FROM portfolio WHERE id = ? AND symbol = ?", $_SESSION["id"], $_POST["symbol"]);
        
        redirect("/");
    }
?>
<?php
    // configuration
    require("../includes/config.php"); 
	 if ($_SERVER["REQUEST_METHOD"] == "GET")
    {
    	$id = $_SESSION["id"];
    	
    	// Retrieves all the transactions from the database ordered by date
    	$positions = CS50::query("SELECT * FROM history WHERE user_id = ?", $_SESSION["id"]);
    	
        // render portfolio
        render("history_form.php", ["positions" => $positions, "tittle" => "history"]);
    }
?>
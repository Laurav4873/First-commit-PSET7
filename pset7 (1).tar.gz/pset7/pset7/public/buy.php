<?php
    // configuration
    require("../includes/config.php"); 
    
    // If user reached via GET
    if ($_SERVER["REQUEST_METHOD"] == "GET")
    {
        render("buy_form.php", ["tittle" => "Buy"]);
    }
    else if($_SERVER["REQUEST_METHOD"] == "POST")
    {
        
        // if symbol or shares empty
        if (empty($_POST["symbol"]) || empty($_POST["shares"]))
        {
            // apologize
            apologize("You must enter a stock symbol and quantity of shares to buy.");
        }
        
        // if shares is invalid (negative)
        if (preg_match("/^\d+$/", $_POST["shares"]) == false)
        {
            // apologize
            apologize("You must enter a whole, positive integer.");
        }
          
        // look up stock's price
            $stock = lookup($_POST["symbol"]);

        // if symbol is not invalid
        if (! $stock)
        {
            // apologize
            apologize("Invalid stock symbol.");
        }
            // calculate total cost (stock's price * shares)
            $cost = $stock["price"] * $_POST["shares"];
            
            // query to check how much cash user has
            $cash_rows = CS50::query("SELECT cash FROM users WHERE id = ?", $_SESSION["id"]);
            $cash = $cash_rows[0]["cash"];
            
            // if user's cash < total cost (user can't afford purchase)
            if ($cash < $cost)
            {
                // apologize
                apologize("You can't afford this purchase.");
            }
            
           
                // update shares
                CS50::query("INSERT INTO portfolio (user_id, symbol, shares) VALUES(?, ?, ?) 
                    ON DUPLICATE KEY UPDATE shares = shares + ?", $_SESSION["id"], $_POST["symbol"], $_POST["shares"],  $_POST["shares"]);
                
                // subtract total price from their cash
                CS50::query("UPDATE users SET cash = cash - ? WHERE id = ?", $cost, $_SESSION["id"]);
                
                // update history
                CS50::query("INSERT INTO history (user_id, transaction, date, symbol, share, price) VALUES (?, 'BUY', NOW(), ?, ?, ?)", $_SESSION["id"], $_POST["symbol"],$_POST["shares"], $stock["price"]);
                //redirect to portfolio
                redirect("/");
    }
    
?>
<?php
    // configuration
    require("../includes/config.php");
    // query user's portfolio
    $rows =	CS50::query("SELECT symbol, shares FROM portfolio WHERE id = ?", $_SESSION["id"]);	
    
	// create new array to store all info for portfolio table
	$positions = [];
    foreach ($rows as $row)
    {
        $stock = lookup($row["symbol"]);
        
        if ($stock !== false)
        {
            $positions[] = [
                "name" => $stock["name"],
                "price" => $stock["price"],
                "shares" => $row["shares"],
                "symbol" => $row["symbol"],
                "total" => $stock["price"] * $row["shares"]
            ];
        }
    }
    
    // query cash for template
    $users = CS50::query("SELECT * FROM users WHERE id = ?", $_SESSION["id"]);
    $user = $users[0];
    // render portfolio (pass in new portfolio table and cash)
    render("portfolio.php", ["title" => "Portfolio", "positions" => $positions,"user"=>$user]);
?>
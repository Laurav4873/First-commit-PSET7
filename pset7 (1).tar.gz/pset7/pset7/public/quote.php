<?php
    // configuration
    require("../includes/config.php"); 
    
    // if form was submitted
    if ($_SERVER["REQUEST_METHOD"] == "POST")
    {
        // Validate the name
        if (empty($_POST["symbol"]))
        {
            apologize("Please enter the stock symbol.");
        }
        
        // Query the Yahoo
        $stock = lookup($_POST["symbol"]);
        
        // Check if we returned nothing
        if ($stock === false)
        {
            apologize("Invalid stock symbol.");
        }
        else
        {
            render("quote.php",["title" => "Quote of ".$stock["name"], "stock" => $stock]);
        }
    }
    else
    {
        // else render form
        render("quote_form.php", ["title" => "Quote"]);
    }
?>